// password-utils.js

const crypto = require('crypto');

// hashPassword function
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex'); // Generate a 16-byte random salt
  const hash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex'); // PBKDF2 hash
  return `${salt}:${hash}`; // Return formatted salt:hash string
}

// verifyPassword function
function verifyPassword(password, storedHash) {
  const [salt, originalHash] = storedHash.split(':'); // Extract the salt and hash
  const hash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex'); // Recompute the hash
  return hash === originalHash; // Compare computed hash with the stored one
}

module.exports = { hashPassword, verifyPassword };
