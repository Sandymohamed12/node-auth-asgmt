# Node Authentication Assignment

This repository contains the code for an authentication-related assignment using Node.js. It demonstrates the implementation of user authentication features such as password hashing and JWT token generation.
