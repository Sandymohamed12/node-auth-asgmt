// jwt-utils.js

const crypto = require('crypto');

// signJWT function
function signJWT(payload, secret, expiresInSeconds = 3600) {
  const header = {
    alg: 'HS256',
    typ: 'JWT'
  };

  // Set the expiration time in the payload
  payload.exp = Math.floor(Date.now() / 1000) + expiresInSeconds;

  // Encode header and payload as base64url
  const encodeBase64url = (str) => {
    return Buffer.from(str).toString('base64')
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');
  };

  const headerEncoded = encodeBase64url(JSON.stringify(header));
  const payloadEncoded = encodeBase64url(JSON.stringify(payload));

  // Create the unsigned JWT (header.payload)
  const unsignedJWT = `${headerEncoded}.${payloadEncoded}`;

  // Sign the unsigned JWT with HMAC-SHA256 using the secret key
  const signature = crypto.createHmac('sha256', secret)
    .update(unsignedJWT)
    .digest('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');

  // Return the complete JWT
  return `${unsignedJWT}.${signature}`;
}

// verifyJWT function
function verifyJWT(token, secret) {
  const [headerEncoded, payloadEncoded, signature] = token.split('.');

  // Recreate the unsigned JWT (header.payload)
  const unsignedJWT = `${headerEncoded}.${payloadEncoded}`;

  // Verify the signature
  const expectedSignature = crypto.createHmac('sha256', secret)
    .update(unsignedJWT)
    .digest('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');

  if (signature !== expectedSignature) {
    throw new Error('Invalid token signature');
  }

  // Decode the payload
  const payload = JSON.parse(Buffer.from(payloadEncoded, 'base64').toString('utf8'));

  // Check the expiration time
  if (payload.exp < Math.floor(Date.now() / 1000)) {
    throw new Error('Token expired');
  }

  return payload;
}

module.exports = { signJWT, verifyJWT };
